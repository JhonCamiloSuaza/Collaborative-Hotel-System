# Hotel System - PostgreSQL Database

Proyecto colaborativo de base de datos para el sistema hotelero.

---

## 🚀 REGLA DE ORO PARA LA SUBIDA

Para asegurar la integridad del proyecto, todos los integrantes deben seguir esta instrucción:

> **"Si la HU indica una CARPETA (termina en `/`), se debe subir la carpeta con TODO su contenido (archivos .sql y .yaml). Si indica un ARCHIVO específico, se sube solo ese archivo."**

---

## 📋 Project Structure

- `01_ddl/`: Data Definition Language (Schemas, Tables, Views, etc.).
- `02_dml/`: Data Manipulation Language (Inserts, Updates, Deletes).
- `03_dcl/`: Data Control Language (Roles, Grants, Policies).
- `04_tcl/`: Transactional Control Language (Transaction blocks).
- `05_rollbacks/`: Rollback scripts for all levels.
- `changelog/`: Liquibase master changelogs.
- `docker/`: Docker configuration files.
- `scripts/`: Helper scripts for the database.
- `tablero_azure_trello_clickup.csv`: Official project tracking board.
- `.gitignore`: Excludes local files and environment variables.

## 🗺️ Mapeo de Entregas (HUs)

| Área | Historias de Usuario | Responsable Principal |
|---|---|---|
| **Estructura e Infraestructura** | HU-01 a HU-06 | Jhon Camilo Suaza Sanchez |
| **Modelado de Dominios (Tablas)** | HU-07 a HU-12 | Danna Valentina Barrios |
| **Lógica, Vistas y Seguridad** | HU-13 a HU-16, HU-21, HU-23 | juan Pablo Gomez Perdomo |
| **Datos, Roles y Transacciones (DML, DCL, TCL)** | HU-17, HU-18, HU-19, HU-20, HU-22 | Johan Steven Rodriguez Charr |

## ⚙️ Configuration of Liquibase

The main entry point is:
`changelog/changelog-master.yaml`

This file includes the master changelogs for each level:
1. `01_ddl/changelog-master.yaml`
2. `02_dml/changelog-master.yaml`
3. `03_dcl/changelog-master.yaml`
4. `04_tcl/changelog-master.yaml`

## 🌊 Flujo de Trabajo (Git Flow)

El trabajo debe seguir estrictamente este flujo de ramas:
`feature/HU-XX -> dev -> qa -> main`

**Está prohibido trabajar directamente en la rama `main`.**

---
